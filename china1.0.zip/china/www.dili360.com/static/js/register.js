/**
 * 执行基本ajax请求,返回XMLHttpRequest
 * Ajax(url,{
 *      method  请求方式 POST or GET(默认)
 *      data    请求参数 (键值对字符串)
 *      success 请求成功后响应函数，参数为xhr
 *      error 请求失败后响应函数，参数为xhr
 * });
 *
 */

var Ajax=function(url,opt){
	    function fn(){}
        var method     = opt.method         || 'GET',
            data     = opt.data         || null,
			type     =opt.type          ||'json',
            success  = opt.success      || fn,
            error    = opt.error        || fn;
		if(method == 'GET' && data){
            url += (url.indexOf('?') == -1 ? '?' : '&') + data;
			data = null;
        }
	
   var xmlhttp=window.XMLHttpRequest?new XMLHttpRequest():new ActiveObject("Microsoft.XMLHTTP");
	    xmlhttp.onreadystatechange=function(){
			handleStateChang(xmlhttp,type,success,error)
			};
		xmlhttp.open(method,url,true);
		if(method=='POST'){
            xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded;charset=utf-8');
			}
		xmlhttp.send(data);
		function handleStateChang(xmlhttp,type,success,error){
			
			if(xmlhttp.readyState==4){
				var s = xmlhttp.status,result;
				if(s>= 200 && s < 300){
					
           switch(type){
                    case 'text':
                        result = xmlhttp.responseText;
                        break;
                    case 'json':
                    result = function(str){
                            return (new Function('return ' + str))();
                        }(xmlhttp.responseText);
                        break;
                    case 'xml':
                        result = xmlhttp.responseXML;
                        break;
                }
                success(result);    
	
					
               }
			   else{
				   error(xmlhttp)
				   }
			   
				}
			
			
			}
		
	
	
	}

var $ = function(id) {
	if (document.getElementById) {
		return document.getElementById(id);
	} else if (document.all) {
		return document.all[id];
	} else if (document.layers) {
		return document.layers[id];
	} else {
		return id;
	}
}

// ----------长度检测
String.prototype.len = function() {
	return this.replace(/[^\x00-\xff]/g, "**").length;
}
var flag = [ 0, 0, 0, 0 ];

// 验证用户名
$('username').onkeyup = function() {
	check_username()
}

function check_username() {

	var uname = $('username').value;
	if (uname.len() > 15) {
		$("idTips").innerHTML = '<em class="no">用户名长度超过限制</em>';
		flag[1] = 0;
	} else if (uname.len() < 1) {
		$("idTips").innerHTML = '<em class="no">用户名不能为空</em>';
		flag[1] = 0;
	} else {
		$("idTips").innerHTML = '';
		flag[1] = 1;

	}

}
$('username').onblur = function() {

	if (flag[1] == 0) {
        check_username()
    } 
    //检测用户名合理性
    /* else {

	$("idTips").innerHTML = '<em class="no">ajax验证中</em>';
		
		var username=$('username').value;
		Ajax(U('/Public/isValidNickName'),{
			type: 'text',
			method : 'POST',
			data : 'username=' + username,
			success : function(reslut) {
				if (reslut == 1) {
					$("idTips").innerHTML = '<em class="yes"> 用户名可用</em>';
					flag[1] = 1;
				} else if (reslut == -1) {
					$("idTips").innerHTML = '<em class="no"> 用户名不合法</em>';
					flag[1] = 0;
				} else if (reslut == -2) {
					$("idTips").innerHTML = '<em class="no">包含不允许注册的词语</em>';
					flag[1] = 0;
				} else {
					$("idTips").innerHTML = '<em class="no">该用户名已经被注册</em>';
					flag[1] = 0;
				}
			},
			error : function() {

				$("idTips").innerHTML = '<em class="no">用户名检测失败，请刷新页面重试</em>';
				flag[1] = 0;

			}
		});

	} */
}
// ----------密码检测

$('pwd').onkeyup = $('pwd').onblur = function() {
	check_password()
}
function check_password() {
	var pwd = $("pwd").value;
	var reChinese = /[\u0391-\uFFE5]+/;
	var b_chinese = reChinese.test(pwd);
	var reSpace = /\s+/;
	var b_space = reSpace.test(pwd);
	// -------长度测试
	if (pwd.length < 6) {
		$("pswTips").innerHTML = '<em class="no"> 密码长度不能小于6</em>';
		flag[2] = 0;
	}
	// -------合法性检测:不能包含汉字
	else if (b_chinese) {
		$("pswTips").innerHTML = '<em class="no">密码不能包含中文</em>';
		flag[2] = 0;
	}
	// -------合法性检测:不能包含空格
	else if (b_space) {
		$("pswTips").innerHTML = '<em class="no">密码不能包含空格</em>';
		flag[2] = 0;
	}
	// -------合法时显示密码强度
	else {
		var num = getResult(pwd);
		var msg = new Array(
				'<span class="left">安全强度：</span><span class="passStrong0"></span><span  class="left">差</span>',
				'<span class="left">安全强度：</span><span class="passStrong1"></span><span  class="left">一般</span>',
				'<span class="left">安全强度：</span><span class="passStrong2"></span><span  class="left">强</span>');
		$("pswTips").innerHTML = msg[num];

		flag[2] = 1;
	}
}
// 定义检测函数,返回0/1/2分别代表差/一般/强
function getResult(s) {
	var ls = -1;
	if (s.match(/[a-z]/ig)) {
		ls++;
	}
	if (s.match(/[0-9]/ig)) {
		ls++;
	}
	if (s.match(/(.[^a-z0-9])/ig)) {
		ls++;
	}
	return ls;
}
// --------检测密码是否一致
$('pwd2').onblur = function() {
	check_is_same()
}
function check_is_same() {
	var pwd = $("pwd").value.toString();
	var check_pwd = $("pwd2").value.toString();
	if (pwd == check_pwd && check_pwd.length > 5) {
		$("pswTips2").innerHTML = '<em class="yes"> 密码可以使用</em>';
		flag[3] = 1;
	} else {
		$("pswTips2").innerHTML = '<em class="no">  两次密码不相同</em>';
		flag[3] = 0;
	}
}
// --------邮箱
$('email').onblur = function() {
	check_email()
}
function check_email() {
	var email = $('email').value;
	var reEmail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	var b_email = reEmail.test(email);
	if (b_email) {

		Ajax(U('/Public/isEmailAvailable'),
				
				{   
					method : 'POST',
					type: 'text',
					data : 'email=' + email,
					success : function(reslut) {
						if (reslut == 1) {
							$("emailTips").innerHTML = '<em class="yes"> 邮箱可用</em>';
							flag[4] = 1;
						} else if (reslut == -4) {
							$("emailTips").innerHTML = '<em class="no"> 格式有误</em>';
							flag[4] = 0;
						} else if (reslut == -5) {
							$("emailTips").innerHTML = '<em class="no"> 不允许注册</em>';
							flag[4] = 0;
						} else if (reslut == -6) {
							$("emailTips").innerHTML = '<em class="no">该邮箱已经被注册,试试<a href="">找回密码？</a></em>';
							flag[4] = 0;
						} else {
							$("emailTips").innerHTML = '<img src="http://my.dili360.com/passport/img/yesok.gif"/><span style="color:green"> 邮箱可用</span>';
							flag[4] = 1;
						}
					},
					error : function() {

						$("emailTips").innerHTML = '<em class="no">邮箱检测失败,请刷新页面重试</em>';
						flag[1] = 0;

					}
				});

	}

	else {
		$("emailTips").innerHTML = '<em class="no">请输入正确的邮箱地址</em>';
		flag[4] = 0;

	}

}

//--------验证码
$('verify').onblur = function() {
	check_verify()
}
function check_verify() {
	var verify = $('verify').value;

		Ajax(U('/Public/isVerify'),
				{   
					method : 'POST',
					type:'text',
					data : 'verify=' + verify,
					success : function(result) {
						if (result == 1) {
							$("verifyTips").innerHTML = '<em class="yes">填写正确</em>';
							flag[5] = 1;
						}else if(result == 0){
							$("verifyTips").innerHTML = '<em class="no">验证码错误</em>';
							flag[5] = 0;
						}
					},
					error : function() {
						$("verifyTips").innerHTML = '<em class="no">系统错误</em>';
						flag[1] = 0;
					}
				});
}

$('reg_submit_btn').onclick = function() {

	if (flag[1] == 0) {
		check_username();
		return false;
	} else if (flag[2] == 0) {
		check_password();
		return false;
	} else if (flag[3] == 0) {
		check_is_same()
		return false;
	}
	if (flag[4] == 0) {
		check_email();
		return false;
	}
	if (flag[5] == 0) {
		check_verify();
		return false;
	}
	else {
		return true;
		$('form1').submit()
	}
}
