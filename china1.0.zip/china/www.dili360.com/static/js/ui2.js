$(document).ready(function(){
	//2014.11.02 by lengyu
	$.each($('.video'),function(index,element){
		var dw = $(this).attr('w');
		var dh = $(this).attr('h');
		var srcVideo = $(this).attr('source');
		var ww = 670;
		var wh = dh/dw*ww;
		$(this).replaceWith("<video controls src="+srcVideo+" width='"+ww+"px' height='"+wh+"px' >你的网页不支持视频播放</video><br><br>");
	});
});